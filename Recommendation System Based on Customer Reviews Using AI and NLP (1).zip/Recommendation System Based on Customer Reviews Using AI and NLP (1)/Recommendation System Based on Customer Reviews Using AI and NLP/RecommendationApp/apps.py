from django.apps import AppConfig


class RecommendationappConfig(AppConfig):
    name = 'RecommendationApp'
